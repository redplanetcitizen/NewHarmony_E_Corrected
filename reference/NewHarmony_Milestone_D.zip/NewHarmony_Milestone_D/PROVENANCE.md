# Provenance — Milestone D

Milestone D is a controlled extension of the exact accepted Milestone C artifact.

## Locked predecessor

`reference/NewHarmony_Milestone_C.zip`

SHA-256: `d613665266a0d75af783745b680451408be0d3fc54b65f41ed8261eb8260c587`

The predecessor's own test suite is replayed during D acceptance.

## New primary data sources

1. `sources/Use_Summary.xlsx` — BEA Summary Use tables, 2019–2023.
2. `sources/ImportMatrices_Before_Redefinitions_Summary.xlsx` — BEA Summary Import Matrices matched to the use framework.

The BEA Import Matrix allocates imported commodities to intermediate and final users. BEA documents that industry-specific imported shares are imputed because direct source data on the imported share of each industry's commodity use are not generally available. D therefore treats the matrix as an official empirical allocation estimate, not as directly observed microdata.

## M08 construction

For each commodity/industry cell, the nominal import-to-domestic-use ratio is formed from the matched Use and Import matrices. It is applied to the accepted C real domestic coefficient cell, producing a dimensionally compatible imported-input coefficient.

Small negative Import-Matrix cells are retained as accounting adjustments in `negative_import_adjustments_nominal.csv` and excluded from physical productive imports. Cells with imported use but a nonpositive derived domestic denominator are retained in `import_nonpositive_domestic_denominator_cells_nominal.csv` and assigned no ratio rather than creating an unstable coefficient.

The real import availability envelope is defined internally and reproducibly as `A_import[t] @ observed_real_domestic_gross_output[t]`. It is therefore coherent with the same price basis and coefficient transformation used by the D solver.

## M09 construction

The domestic component of BEA F030 is converted from nominal flow to the C 2019-price basis using the corresponding sector gross-output price relative. The resulting signed series is an inventory-change diagnostic, not an absolute inventory stock.

The endogenous planner uses zero beginning modeled inventory and an empirical flow-throughput envelope equal to the absolute real F030 movement in each sector/year. This deliberately avoids inventing an unobserved absolute 2018 inventory stock. The envelope is a conservative benchmark assumption and is explicitly not interpreted as physical warehouse capacity.

## Source hashes

See `SOURCE_MANIFEST.csv` and `PACKAGE_MANIFEST.csv`.
