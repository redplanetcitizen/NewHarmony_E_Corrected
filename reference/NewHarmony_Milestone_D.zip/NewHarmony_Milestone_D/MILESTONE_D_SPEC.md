# Milestone D specification — accepted M08/M09 contract

1. Preserve Milestone C exactly when M08 and M09 are disabled.
2. Keep imports outside the 71 domestic industries.
3. Apply domestic capital and FTE constraints only to domestic production.
4. Impose an explicit imported-intermediate availability constraint.
5. Preserve the domestic social plan ray inherited from C; do not re-add direct final imports already removed in target construction.
6. Treat F030 as an inventory change, not an inventory stock or ordinary target.
7. Convert inventory changes to the common 2019-price basis before intertemporal accounting.
8. Do not allow the planner to withdraw from an unknown pre-2019 inventory stock.
9. Permit only source-year < destination-year inventory transfers.
10. Reject any capital or inventory transfer that fails to increase mean intertemporal Harmony.
11. Preserve Frozen and Historical technology modes, including the corresponding frozen/historical import coefficient mode.
12. Keep observed gross output, stock, investment, imports and F030 as validation/resource data rather than calibration targets.
