# New Harmony — Milestone D

## Status

**ACCEPTED.** Milestone D adds explicit imported-intermediate resource accounting (M08) and a conservative dynamic-inventory state (M09) to the accepted Milestone C solver.

The exact accepted Milestone C archive is embedded under `reference/`. Its SHA-256 is:

`d613665266a0d75af783745b680451408be0d3fc54b65f41ed8261eb8260c587`

The predecessor archive was replayed from its own bytes and passed **15/15** tests. The Milestone D acceptance suite passes **25/25** tests.

## What changes

### M08 — explicit imports

Imported intermediate inputs are represented as an external productive source rather than as a U.S. industry. They therefore do not consume domestic FTE or domestic capital. The imported-input coefficient matrix is derived from the BEA Summary Use Table and Import Matrix through the cellwise import/domestic-use ratio and placed on the same 2019-price coefficient basis as Milestone C:

`A_import[t] = A_domestic[t] * (Import_nominal[t] / DomesticUse_nominal[t])`

where the ratio is used only where the domestic denominator is positive. Eight small negative Import-Matrix adjustment cells and 23 nonpositive-denominator cells are retained in explicit audit files and excluded from productive coefficients rather than silently clipped into physical imports.

Imports are not free. Each year has a componentwise real import envelope:

`import_cap[t] = A_import[t] @ observed_domestic_gross_output[t]`

and every evaluated plan must satisfy imported-intermediate requirements below that envelope. Frozen technology freezes both domestic and imported technical coefficients at 2019; Historical uses annual coefficients.

Milestone C's social targets were already constructed from domestic final use (`Use - direct imports`) with fixed investment and F030 inventories excluded. The accepted D benchmark therefore **does not re-add direct final imports to the plan ray**, which would double count a component deliberately removed in the predecessor target construction. Direct final-import allocations remain in the D audit dataset.

### M09 — dynamic inventories

BEA F030 is a flow — change in private inventories — rather than an absolute inventory stock. D converts the domestic F030 flows to the common 2019-price basis and records the diagnostic state recurrence:

`Q[t+1] = Q[t] + DeltaQ[t]`.

Because no defensible 71-sector absolute beginning-2019 stock is available in the accepted data package, the planner mode does not borrow from an unknown pre-plan stock. Endogenous inventory must be produced in an earlier modeled year and released only in a later year. Inventory stock may never become negative.

For the 2019–2023 empirical benchmark, planned positive/negative inventory flow in each sector/year is conservatively bounded by the absolute observed real F030 movement for that sector/year. This is a **flow-throughput envelope, not an estimate of storage capacity**. A transfer is accepted only if it raises mean intertemporal Harmony.

## Accepted benchmark results

| Configuration | Technology | Capital transfers | Inventory transfers | Final mean H | Final CV | 5y import requirement / cap |
|---|---|---:|---:|---:|---:|---:|
| C replay | Frozen | 111 | 0 | 0.429414054 | 0.072213654 | — |
| M08 only | Frozen | 111 | 0 | 0.429414054 | 0.072213654 | 68.70% |
| M08 + M09 | Frozen | 111 | 0 | 0.429414054 | 0.072213654 | 68.70% |
| C replay | Historical | 142 | 0 | 0.417848385 | 0.091994000 | — |
| M08 only | Historical | 142 | 0 | 0.417848385 | 0.091994000 | 64.60% |
| M08 + M09 | Historical | 142 | 0 | 0.417848385 | 0.091994000 | 64.60% |

M08 is therefore **nonbinding in the accepted historical backtest**: the endogenously selected domestic plans require substantially less imported intermediate availability than the model-consistent observed envelope. This is why the C capital-allocation path is preserved.

M09 accepts **zero** inventory transfers on the real 2019–2023 data under the conservative sector/year F030 envelope: no admissible forward transfer increases mean Harmony. This is an empirical result of the specified envelope, not a disabled algorithm. The acceptance suite contains a one-product, two-period synthetic case in which the same inventory search accepts forward transfers and raises mean Harmony.

## Main files

- `code/new_harmony_empirical_c.py` — exact predecessor solver source carried into D.
- `code/new_harmony_empirical_d.py` — integrated M08/M09 solver and six benchmark runner.
- `code/build_bea_trade_inventory_data.py` — reproducible BEA Use/Import/F030 extraction.
- `data/intermediate_import_to_domestic_ratio_*.csv` — annual imported-input ratios.
- `data/inventory_change_F030_real_2019price.csv` — real inventory-flow diagnostic and envelope.
- `results/comparison/BENCHMARK_HEADLINE.csv` — six accepted headline runs.
- `results/comparison/BENCHMARK_ANNUAL.csv` — annual comparison.
- `results/TEST_REPORT.txt` — 25/25 Milestone D acceptance run.
- `results/c_replay/TEST_REPORT_C.txt` — independent 15/15 predecessor replay.
- `reference/NewHarmony_Milestone_C.zip` — exact accepted predecessor bytes.
- `MILESTONE_D_ACCEPTANCE.md` — acceptance gates and interpretation boundary.

## Interpretation boundary

Milestone D does not calibrate investment, imports, or inventories to force historical output. M08 supplies an external availability constraint; M09 supplies a conservative intertemporal goods-transfer mechanism. Both remain subordinate to the New Harmony rule: capital or inventory reallocations are accepted only when mean intertemporal Harmony rises.

The persistent 2019–2023 gap between modeled and observed U.S. investment therefore remains a research result. D shows that merely making observed-scale intermediate imports explicit, and adding conservative inventory transfer capacity, does not eliminate that gap.
