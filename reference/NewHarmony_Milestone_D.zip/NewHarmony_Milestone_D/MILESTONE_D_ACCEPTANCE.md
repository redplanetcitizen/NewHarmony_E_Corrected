# Milestone D acceptance

**Status: ACCEPTED — 2026-08-20**

## Predecessor lock

- [x] Exact uploaded `NewHarmony_Milestone_C.zip` embedded in `reference/`.
- [x] SHA-256 equals `d613665266a0d75af783745b680451408be0d3fc54b65f41ed8261eb8260c587`.
- [x] Predecessor replay from its own archive passes 15/15 tests.
- [x] Frozen locked result reproduced: 111 transfers, final mean H 0.4294140538902201, CV 0.07221365449987416.
- [x] Historical locked result reproduced: 142 transfers, final mean H 0.4178483854400241, CV 0.09199400014123144.

## M08 gates

- [x] Imports remain external to domestic capital and FTE accounting.
- [x] Imported-input coefficients are finite, nonnegative and 5 × 71 × 71.
- [x] Frozen import technology uses 2019 coefficients for every year; Historical uses annual coefficients.
- [x] Componentwise real import envelopes are explicit.
- [x] Final plans do not exceed any import envelope.
- [x] `imports_off, inventories_off` is a numerical no-op relative to C.
- [x] C domestic target semantics are unchanged; direct final imports are not double counted.
- [x] Negative accounting adjustments and nonpositive domestic denominators remain auditable.

## M09 gates

- [x] F030 is kept outside the ordinary social target.
- [x] F030 is converted to 2019-price real flow before multiyear state accounting.
- [x] Diagnostic state obeys `Q[t+1] = Q[t] + DeltaQ[t]`.
- [x] Planner inventory cannot borrow from an unknown pre-2019 stock.
- [x] Planner inventory stock cannot become negative.
- [x] Endogenous transfers are strictly forward in time.
- [x] Sector/year planner inventory flow is bounded by the conservative absolute-real-F030 envelope.
- [x] A transfer can be accepted only for positive mean-Harmony gain.
- [x] Synthetic acceptance test demonstrates that the inventory mechanism can accept a beneficial transfer.
- [x] Real 2019–2023 benchmark accepts zero transfers because no admissible transfer has positive gain.

## Full acceptance suite

**25 tests run; 25 passed.**

See `results/TEST_REPORT.txt`.

## Accepted interpretation

The equality of the C, M08-only, and M08+M09 headline Harmony results in the accepted backtest is not produced by disabling D. M08 is active but nonbinding at the selected plans. M09 is active but finds no positive-gain transfer within the conservative empirical flow envelope. Both facts are test-covered outputs.

Milestone D is therefore frozen as the **imports + inventories baseline**. A later milestone may investigate trade-balance/foreign-exchange constraints, alternative import-availability scenarios, or independently sourced absolute inventory stocks without revising D retroactively.
