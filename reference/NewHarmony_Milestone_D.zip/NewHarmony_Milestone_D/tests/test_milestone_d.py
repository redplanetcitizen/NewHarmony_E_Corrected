from __future__ import annotations
import csv, hashlib, json, subprocess, sys, tempfile, unittest, zipfile, warnings
from pathlib import Path
import numpy as np

warnings.simplefilter('ignore', ResourceWarning)
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
import new_harmony_empirical_c as c
import new_harmony_empirical_d as d
from build_bea_trade_inventory_data import build, EXPECTED_SOURCE_SHA256

DATA=ROOT/'data'; RESULTS=ROOT/'results'; REF=ROOT/'reference'; SOURCES=ROOT/'sources'
EXPECTED_C_SHA='d613665266a0d75af783745b680451408be0d3fc54b65f41ed8261eb8260c587'
LOCKED={
 'frozen': {'transfers':111,'mean':0.4294140538902201,'cv':0.07221365449987416},
 'historical': {'transfers':142,'mean':0.4178483854400241,'cv':0.09199400014123144},
}

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


class MilestoneDAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.audit=build(SOURCES/'Use_Summary.xlsx',SOURCES/'ImportMatrices_Before_Redefinitions_Summary.xlsx',DATA)
        cls.data={}; cls.trade={}; cls.cres={}; cls.m08={}; cls.full={}
        for mode in ('frozen','historical'):
            md=c.load_model_data(DATA,mode); tr=d.load_trade_inventory(md,DATA)
            cls.data[mode]=md; cls.trade[mode]=tr
            cls.cres[mode]=c.solve(md)
            cls.m08[mode]=d.solve_configuration(md,tr,imports_enabled=True,inventories_enabled=False)
            cls.full[mode]=d.solve_configuration(md,tr,imports_enabled=True,inventories_enabled=True)

    def test_01_predecessor_sha_is_exact(self):
        self.assertEqual(sha256(REF/'NewHarmony_Milestone_C.zip'),EXPECTED_C_SHA)

    def test_02_exact_predecessor_archive_replays_15_tests(self):
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(REF/'NewHarmony_Milestone_C.zip') as z: z.extractall(td)
            pkg=Path(td)/'NewHarmony_Milestone_C'
            proc=subprocess.run([sys.executable,'-m','unittest','-q','tests.test_milestone_c'],cwd=pkg,text=True,capture_output=True,timeout=90)
            self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)
            text=proc.stdout+proc.stderr
            self.assertIn('Ran 15 tests',text)
            self.assertIn('OK',text)

    def test_03_exact_five_year_71_sector_contract(self):
        for md in self.data.values():
            self.assertEqual(md.years,[2019,2020,2021,2022,2023])
            self.assertEqual(len(md.sectors),71)
            self.assertEqual(md.goals.shape,(5,71))

    def test_04_locked_bea_source_hashes(self):
        for name,expected in EXPECTED_SOURCE_SHA256.items():
            self.assertEqual(sha256(SOURCES/name),expected)

    def test_05_import_data_identities_and_audit_exceptions(self):
        diag=self.audit['diagnostics']
        self.assertLessEqual(diag['max_use_domestic_plus_import_identity_error'],1e-9)
        self.assertLessEqual(diag['max_final_domestic_plus_import_identity_error'],1e-9)
        self.assertEqual(diag['negative_import_adjustment_cells_excluded_from_productive_ratio'],8)
        self.assertEqual(diag['import_cells_with_nonpositive_domestic_denominator_excluded_from_ratio'],23)

    def test_06_import_coefficients_are_finite_nonnegative(self):
        for tr in self.trade.values():
            self.assertEqual(tr.import_A_by_year.shape,(5,71,71))
            self.assertTrue(np.isfinite(tr.import_A_by_year).all())
            self.assertTrue((tr.import_A_by_year>=-1e-12).all())
            self.assertTrue((tr.import_cap_by_year>=-1e-12).all())

    def test_07_frozen_and_historical_import_technology_modes(self):
        tf=self.trade['frozen']; th=self.trade['historical']
        self.assertTrue(np.allclose(tf.import_A_by_year[0],tf.import_A_by_year[4]))
        self.assertFalse(np.allclose(th.import_A_by_year[0],th.import_A_by_year[4]))
        self.assertTrue(np.allclose(tf.import_A_by_year[0],th.import_A_by_year[0]))

    def test_08_inventory_F030_is_real_before_state_accumulation(self):
        tr=self.trade['frozen']
        self.assertEqual(tr.inventory_change_real.shape,(5,71))
        self.assertTrue(np.isfinite(tr.inventory_change_real).all())
        self.assertTrue(np.allclose(tr.inventory_flow_envelope,np.abs(tr.inventory_change_real)))
        path=np.vstack([np.zeros(71),np.cumsum(tr.inventory_change_real,axis=0)])
        for t in range(5):
            np.testing.assert_allclose(path[t+1],path[t]+tr.inventory_change_real[t])

    def test_09_frozen_C_replay_locked(self):
        r=self.cres['frozen']; lk=LOCKED['frozen']
        self.assertEqual(len(r.transfers),lk['transfers'])
        self.assertAlmostEqual(r.final.mean_harmony,lk['mean'],places=12)
        self.assertAlmostEqual(r.final.cv_harmony,lk['cv'],places=12)

    def test_10_historical_C_replay_locked(self):
        r=self.cres['historical']; lk=LOCKED['historical']
        self.assertEqual(len(r.transfers),lk['transfers'])
        self.assertAlmostEqual(r.final.mean_harmony,lk['mean'],places=12)
        self.assertAlmostEqual(r.final.cv_harmony,lk['cv'],places=12)

    def test_11_imports_off_inventories_off_is_numeric_noop(self):
        for mode in ('frozen','historical'):
            md=self.data[mode]; tr=self.trade[mode]
            rd=d.solve_configuration(md,tr,imports_enabled=False,inventories_enabled=False)
            rc=self.cres[mode]
            self.assertEqual(len(rd.capital_transfers),len(rc.transfers))
            np.testing.assert_allclose(rd.final.annual_harmony,rc.final.annual_harmony,rtol=0,atol=5e-15)
            np.testing.assert_allclose(rd.final.gross_realized,rc.final.gross_realized,rtol=0,atol=2e-7)
            np.testing.assert_allclose(rd.final.stock_end,rc.final.stock_end,rtol=0,atol=2e-7)
            np.testing.assert_allclose(rd.final.investments,rc.final.investments,rtol=0,atol=2e-7)

    def test_12_M08_only_preserves_capital_path_in_accepted_backtest(self):
        for mode in ('frozen','historical'):
            r=self.m08[mode]; rc=self.cres[mode]
            self.assertEqual(len(r.capital_transfers),len(rc.transfers))
            self.assertEqual(r.stop_reason_capital,'no_positive_transfer')
            self.assertAlmostEqual(r.final.mean_harmony,rc.final.mean_harmony,places=12)
            self.assertAlmostEqual(r.final.cv_harmony,rc.final.cv_harmony,places=12)

    def test_13_M08_import_caps_are_explicit_and_nonbinding_at_solution(self):
        for mode,r in self.m08.items():
            self.assertGreater(float(r.final.imported_intermediate_required.sum()),0.0)
            self.assertGreater(float(r.final.imported_intermediate_cap.sum()),float(r.final.imported_intermediate_required.sum()))
            self.assertLessEqual(float(np.max(r.final.imported_intermediate_required-r.final.imported_intermediate_cap)),1e-7)

    def test_14_M08_does_not_add_imports_to_domestic_FTE_or_capital(self):
        for mode in ('frozen','historical'):
            rc=self.cres[mode]; r=self.m08[mode]
            np.testing.assert_allclose(r.final.gross_realized,rc.final.gross_realized,rtol=0,atol=2e-7)
            np.testing.assert_allclose(r.final.stock_end,rc.final.stock_end,rtol=0,atol=2e-7)

    def test_15_C_domestic_social_target_semantics_are_preserved(self):
        # Milestone C's goals were already built from Use minus direct imports, with
        # fixed investment and F030 excluded. M08 must not silently re-add final imports.
        df=c.load_model_data(DATA,'frozen')
        expected=[17543938.25928459,17019784.716033217,17989284.039679337,18463542.52515483,19099011.83487909]
        np.testing.assert_allclose(df.goals.sum(axis=1),expected,rtol=0,atol=1e-6)

    def test_16_planner_inventory_tensor_forbids_preplan_or_backward_release(self):
        md=self.data['frozen']; tr=self.trade['frozen']
        bad=np.zeros((5,5,71)); bad[1,0,0]=1.0
        with self.assertRaises(ValueError): d.evaluate_d(md,tr,np.zeros((5,71,71)),bad,imports_enabled=False,inventories_enabled=True)

    def test_17_synthetic_inventory_transfer_is_forward_and_positive_gain(self):
        T=N=1
        # Use two periods and one storable product so a real intertemporal transfer
        # can improve concave mean Harmony without any vector-aggregation ambiguity.
        md=c.ModelData(years=[2019,2020],sectors=['X'],names={'X':'X'},A_by_year=np.zeros((2,1,1)),L_by_year=np.ones((2,1,1)),C=np.zeros((1,1)),dep_by_year=np.zeros((2,1,1)),initial_stock=np.zeros((1,1)),goals=np.array([[10.],[10.]]),labour_coeff_by_year=np.ones((2,1)),labour_available=np.array([20.,5.]),observed_gross={2019:np.array([10.]),2020:np.array([10.])},observed_stock={2018:np.array([0.]),2019:np.array([0.]),2020:np.array([0.])},observed_investment={2019:np.array([0.]),2020:np.array([0.])},mode='frozen')
        tr=d.TradeInventoryData(np.zeros((2,1,1)),np.full((2,1),100.),np.zeros((2,1)),np.full((2,1),10.))
        base=d.evaluate_d(md,tr,np.zeros((2,1,1)),imports_enabled=False,inventories_enabled=True)
        _,fin,tensor,logs,stop,_=d.balance_inventories(md,tr,base,imports_enabled=False,maxiter=5)
        self.assertGreater(len(logs),0)
        self.assertGreater(fin.mean_harmony,base.mean_harmony)
        self.assertGreater(tensor[0,1,0],0.0)
        for row in logs:
            self.assertLess(row['source_year'],row['destination_year'])
            self.assertGreater(row['gain'],0.0)

    def test_18_real_M09_respects_empirical_flow_envelope(self):
        for mode,r in self.full.items():
            net=np.abs(r.final.inventory_accumulation-r.final.inventory_release)
            self.assertTrue(np.all(net<=self.trade[mode].inventory_flow_envelope+1e-7))
            self.assertTrue(np.all(r.final.inventory_end>=-1e-9))

    def test_19_real_M09_accepts_no_nonpositive_transfer(self):
        # On the accepted 2019-2023 data, no sector-specific transfer inside the
        # conservative F030 flow envelope raises mean Harmony. Zero is a valid result.
        for mode,r in self.full.items():
            self.assertEqual(r.stop_reason_inventory,'no_positive_inventory_transfer')
            self.assertEqual(len(r.inventory_transfers_log),0)
            self.assertEqual(float(r.final.inventory_accumulation.sum()),0.0)
            self.assertEqual(float(r.final.inventory_release.sum()),0.0)

    def test_20_all_accepted_capital_transfers_are_forward_positive_gain(self):
        for collection in (self.m08,self.full):
            for r in collection.values():
                for row in r.capital_transfers:
                    self.assertLess(row['source_year'],row['destination_year'])
                    self.assertGreater(row['gain'],0.0)

    def test_21_final_D_scenarios_are_feasible_and_nonnegative(self):
        for collection in (self.m08,self.full):
            for r in collection.values():
                self.assertGreaterEqual(float(np.min(r.final.production_scale)),-1e-9)
                self.assertGreaterEqual(float(np.min(r.final.net_social_output)),-1e-7)
                self.assertTrue(np.isfinite(r.final.annual_harmony).all())
                self.assertLessEqual(float(np.max(r.final.imported_intermediate_required-r.final.imported_intermediate_cap)),1e-7)

    def test_22_headline_contains_all_six_required_benchmarks(self):
        rows=list(csv.DictReader(open(RESULTS/'comparison'/'BENCHMARK_HEADLINE.csv',encoding='utf-8')))
        self.assertEqual(len(rows),6)
        keys={(r['configuration'],r['technology_mode']) for r in rows}
        self.assertEqual(keys,{(a,b) for a in ('c_replay','m08_only','m08_m09') for b in ('frozen','historical')})

    def test_23_M08_import_requirement_is_material_but_below_envelope(self):
        for mode,r in self.m08.items():
            ratio=float(r.final.imported_intermediate_required.sum()/r.final.imported_intermediate_cap.sum())
            self.assertGreater(ratio,0.60)
            self.assertLess(ratio,0.75)

    def test_24_real_inventory_diagnostic_is_small_relative_to_social_target(self):
        md=self.data['frozen']; tr=self.trade['frozen']
        self.assertLess(float(tr.inventory_flow_envelope.sum()/md.goals.sum()),0.01)

    def test_25_results_preserve_structural_validation(self):
        for label in ('m08_only','m08_m09'):
            for mode in ('frozen','historical'):
                rows=list(csv.DictReader(open(RESULTS/label/mode/'historical_comparison_summary.csv',encoding='utf-8')))
                self.assertGreater(min(float(r['gross_corr']) for r in rows),0.90)
                self.assertGreater(min(float(r['stock_corr']) for r in rows),0.99)

if __name__=='__main__': unittest.main(verbosity=2)
