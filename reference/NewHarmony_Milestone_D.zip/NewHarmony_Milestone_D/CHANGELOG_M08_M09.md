# Changelog — M08/M09

## Preserved from Milestone C

M01–M07 remain unchanged: five-year 2019–2023 objective horizon; beginning/end-year capital timing; marginal capacity-targeted accumulation; 71×71 capital composition; physical FTE labour; 2019-price quantities; Frozen and Historical technology modes. The Harmony function and positive-mean-H acceptance rule are unchanged.

## M08

Added an explicit imported-intermediate coefficient matrix and componentwise annual availability envelope. Imported intermediates are external inputs and carry no U.S. capital or FTE coefficients. The source is the BEA Summary Import Matrix matched to the Summary Use Table. The accepted benchmark preserves C's domestic social target and therefore does not re-add direct final imports.

## M09

Added an inventory state and forward transfer tensor. Historical F030 is converted to 2019-price volume and retained as an observed change/deviation path. Endogenous planner inventory begins at zero, cannot become negative, and can only be created in a modeled source year before later release. The empirical backtest bounds annual sector flows by absolute observed real F030 movement and accepts only positive mean-H transfers.

## Candidate-to-accepted change

The candidate package supplied M08/M09 primitives and data audits but lacked the exact predecessor bytes. The accepted package adds the exact Milestone C archive, replays its 15/15 tests, integrates M08/M09 into the executable solver, produces six comparable benchmarks, and adds a 25-test acceptance contract.
